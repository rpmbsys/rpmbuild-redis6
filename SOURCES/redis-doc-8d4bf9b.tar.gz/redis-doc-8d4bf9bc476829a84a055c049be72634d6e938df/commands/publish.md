Posts a message to the given channel.

@return

@integer-reply: the number of clients that received the message.
