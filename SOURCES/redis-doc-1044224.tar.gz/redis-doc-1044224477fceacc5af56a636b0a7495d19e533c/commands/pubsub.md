This is a container command for Pub/Sub introspection commands.

To see the list of available commands you can call `PUBSUB HELP`.
