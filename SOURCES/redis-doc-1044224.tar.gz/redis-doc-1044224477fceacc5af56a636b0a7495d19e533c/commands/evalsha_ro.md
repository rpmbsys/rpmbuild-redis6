This is a read-only variant of the `EVALSHA` command that cannot execute commands that modify data.

For more information about when to use this command vs `EVALSHA`, please refer to [Read-only scripts](/docs/manual/programmability/#read-only-scripts).

For more information about `EVALSHA` scripts please refer to [Introduction to Eval Scripts](/topics/eval-intro).
