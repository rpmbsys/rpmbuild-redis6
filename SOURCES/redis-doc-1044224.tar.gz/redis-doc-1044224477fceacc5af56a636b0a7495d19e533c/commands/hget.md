Returns the value associated with `field` in the hash stored at `key`.

@examples

```cli
HSET myhash field1 "foo"
HGET myhash field1
HGET myhash field2
```
