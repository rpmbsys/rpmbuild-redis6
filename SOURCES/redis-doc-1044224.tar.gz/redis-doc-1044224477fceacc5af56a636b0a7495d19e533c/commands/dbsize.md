Return the number of keys in the currently-selected database.
