Returns @integer-reply of number of total commands in this Redis server.

@examples

```cli
COMMAND COUNT
```
