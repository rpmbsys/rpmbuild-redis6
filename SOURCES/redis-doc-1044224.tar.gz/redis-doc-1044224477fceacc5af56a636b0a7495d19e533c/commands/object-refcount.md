This command returns the reference count of the stored at `<key>`.
