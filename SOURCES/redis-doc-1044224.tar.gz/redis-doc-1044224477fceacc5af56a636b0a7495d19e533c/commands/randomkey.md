Return a random key from the currently selected database.
