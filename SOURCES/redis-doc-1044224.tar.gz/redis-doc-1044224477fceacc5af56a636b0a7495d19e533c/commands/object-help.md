The `OBJECT HELP` command returns a helpful text describing the different subcommands.
