Returns all field names in the hash stored at `key`.

@examples

```cli
HSET myhash field1 "Hello"
HSET myhash field2 "World"
HKEYS myhash
```
