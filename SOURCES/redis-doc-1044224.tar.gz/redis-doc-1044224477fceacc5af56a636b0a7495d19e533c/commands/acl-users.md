The command shows a list of all the usernames of the currently configured
users in the Redis ACL system.

@examples

```
> ACL USERS
1) "anna"
2) "antirez"
3) "default"
```
