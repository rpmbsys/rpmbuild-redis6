This is a container command for script management commands.

To see the list of available commands you can call `SCRIPT HELP`.
