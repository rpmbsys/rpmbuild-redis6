The `CLUSTER HELP` command returns a helpful text describing the different subcommands.

@return

@array-reply: a list of subcommands and their descriptions
