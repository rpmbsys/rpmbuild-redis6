The command shows a list of all the usernames of the currently configured
users in the Redis ACL system.

@return

An array of strings.

@examples

```
> ACL USERS
1) "anna"
2) "antirez"
3) "default"
```
