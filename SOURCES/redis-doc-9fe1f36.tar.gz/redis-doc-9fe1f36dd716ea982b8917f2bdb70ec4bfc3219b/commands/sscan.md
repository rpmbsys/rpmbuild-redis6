See `SCAN` for `SSCAN` documentation.
